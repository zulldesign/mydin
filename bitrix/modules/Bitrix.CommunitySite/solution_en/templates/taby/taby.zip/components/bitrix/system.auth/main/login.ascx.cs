using System;
using Bitrix.UI;

public partial class bitrix_components_bitrix_system_auth_templates__default_login : BXComponentTemplate
{
}
